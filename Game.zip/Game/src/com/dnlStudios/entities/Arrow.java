package com.dnlStudios.entities;

import java.awt.image.BufferedImage;

public class Arrow extends Entity{

	public Arrow(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
	}

}
