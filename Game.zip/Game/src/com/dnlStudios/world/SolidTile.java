package com.dnlStudios.world;

import java.awt.image.BufferedImage;

public class SolidTile extends Tileset{

	public SolidTile(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
	}

}
