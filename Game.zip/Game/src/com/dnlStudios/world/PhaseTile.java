package com.dnlStudios.world;

import java.awt.image.BufferedImage;

public class PhaseTile extends Tileset{

	public PhaseTile(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
	}

}
